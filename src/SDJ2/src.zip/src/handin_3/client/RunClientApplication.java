package handin_3.client;

import javafx.application.Application;

public class RunClientApplication {
    public static void main(String[] args) {
        Application.launch(ClientApplication.class);
    }
}
