package handin_3.client.viewModel;

import handin_3.shared.Subject;

public interface ViewModel extends Subject {
}
